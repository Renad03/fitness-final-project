
import React, { useState } from "react";
import "./App.css";
import { FaEnvelope, FaLock } from "react-icons/fa";

function App() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="container mt-5">
      <div className="tabs">
        <span
          className={isLogin ? "active" : ""}
          onClick={() => setIsLogin(true)}
        >
          Login
        </span>
        <span
          className={!isLogin ? "active" : ""}
          onClick={() => setIsLogin(false)}
        >
          Signup
        </span>
      </div>

      {isLogin ? (
        <form>
          <label>Email</label>
          <div className="input-box">
            <span className="icon"><FaEnvelope /></span>
            <input type="email" placeholder="Enter your email" />
          </div>

          <label>Password</label>
          <div className="input-box">
            <span className="icon"><FaLock /></span>
            <input type="password" placeholder="Enter your password" />
          </div>

          <button type="submit" className="btn">Login</button>

          <div className="or-line"><span>or</span></div>

          <button className="google-btn">Login with Google</button>
        </form>
      ) : (
        <form>
          <label>Username</label>
          <div className="input-box">
            <span className="icon"><FaEnvelope /></span>
            <input type="text" placeholder="Enter your username" />
          </div>

          <label>Email</label>
          <div className="input-box">
            <span className="icon"><FaEnvelope /></span>
            <input type="email" placeholder="Enter your email" />
          </div>

          <label>Password</label>
          <div className="input-box">
            <span className="icon"><FaLock /></span>
            <input type="password" placeholder="Enter your password" />
          </div>

          <label>Confirm Password</label>
          <div className="input-box">
            <span className="icon"><FaLock /></span>
            <input type="password" placeholder="Confirm your password" />
          </div>

          <button type="submit" className="btn">Signup</button>

          <div className="or-line"><span>or</span></div>

          <button className="google-btn">Signup with Google</button>
        </form>
      )}
    </div>
  );
}

export default App;
